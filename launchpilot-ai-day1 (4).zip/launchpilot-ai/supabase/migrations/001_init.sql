-- Run in Supabase SQL Editor. Admin enrollment is manual and intentional.
create extension if not exists pgcrypto;
create table if not exists public.admins (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.leads (
 id uuid primary key default gen_random_uuid(),
 name text not null check (char_length(name) between 2 and 100),
 email text not null check (char_length(email) between 3 and 254),
 phone text check (phone is null or char_length(phone)<=30),
 message text not null check (char_length(message) between 10 and 2000),
 status text not null default 'new' check(status in ('new','contacted','qualified','won','lost')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists leads_created_idx on public.leads(created_at desc);
create table if not exists public.lead_rate_limits (
 ip_hash text not null,
 bucket timestamptz not null,
 count int not null default 0,
 primary key(ip_hash,bucket)
);
create or replace function public.set_lead_updated_at() returns trigger language plpgsql as $$
begin new.updated_at=now();return new;end;$$;
drop trigger if exists leads_updated_at on public.leads;
create trigger leads_updated_at before update on public.leads for each row execute function public.set_lead_updated_at();
alter table public.admins enable row level security;
alter table public.leads enable row level security;
alter table public.lead_rate_limits enable row level security;
revoke all on public.admins, public.leads, public.lead_rate_limits from anon,authenticated;
grant select on public.admins to authenticated;
grant select,update(status) on public.leads to authenticated;
drop policy if exists admin_can_read_own_record on public.admins;
create policy admin_can_read_own_record on public.admins for select to authenticated using(user_id=(select auth.uid()));
drop policy if exists admins_read_leads on public.leads;
create policy admins_read_leads on public.leads for select to authenticated using(exists(select 1 from public.admins where user_id=(select auth.uid())));
drop policy if exists admins_update_leads on public.leads;
create policy admins_update_leads on public.leads for update to authenticated using(exists(select 1 from public.admins where user_id=(select auth.uid()))) with check(exists(select 1 from public.admins where user_id=(select auth.uid())));
-- Atomic rate limiting and insert, only callable by service_role.
create or replace function public.submit_public_lead(p_name text,p_email text,p_phone text,p_message text,p_ip_hash text)
returns text language plpgsql security definer set search_path='' as $$
declare current_bucket timestamptz:=date_trunc('hour',now());n int;
begin
 if char_length(p_name) not between 2 and 100 or char_length(p_email) not between 3 and 254 or char_length(p_message) not between 10 and 2000 or (p_phone is not null and char_length(p_phone)>30) or char_length(p_ip_hash)<>64 then
   raise exception 'Invalid input';
 end if;
 insert into public.lead_rate_limits(ip_hash,bucket,count) values(p_ip_hash,current_bucket,1)
 on conflict(ip_hash,bucket) do update set count=public.lead_rate_limits.count+1 returning count into n;
 if n>5 then return 'rate_limited';end if;
 insert into public.leads(name,email,phone,message) values(p_name,p_email,p_phone,p_message);
 return 'created';
end;$$;
revoke all on function public.submit_public_lead(text,text,text,text,text) from public,anon,authenticated;
grant execute on function public.submit_public_lead(text,text,text,text,text) to service_role;
-- Suggested scheduled cleanup: delete from public.lead_rate_limits where bucket < now()-interval '2 days';
