 'use client';
import { useState, type FormEvent } from 'react';
export default function LeadForm(){
 const [busy,setBusy]=useState(false);const [result,setResult]=useState('');const [ok,setOk]=useState(false);
 async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setBusy(true);setResult('');setOk(false);
 const form=e.currentTarget;const data=Object.fromEntries(new FormData(form).entries());
 try{const res=await fetch('/api/leads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 const json=await res.json();if(!res.ok)throw new Error(json.error||'Unable to submit');setResult('Thanks! Your inquiry has been received.');setOk(true);form.reset();}
 catch(err){setResult(err instanceof Error?err.message:'Unexpected error');}finally{setBusy(false)}
 }
 return <form onSubmit={submit} className="panel"><h2>Request a consultation</h2><p className="muted">Try the public lead form.</p>
 <div className="field"><label htmlFor="name">Name</label><input id="name" name="name" minLength={2} maxLength={100} required/></div>
 <div className="field"><label htmlFor="email">Email</label><input id="email" name="email" type="email" maxLength={254} required/></div>
 <div className="field"><label htmlFor="phone">Phone (optional)</label><input id="phone" name="phone" maxLength={30}/></div>
 <div className="field"><label htmlFor="message">How can we help?</label><textarea id="message" name="message" minLength={10} maxLength={2000} required/></div>
 <div aria-hidden="true" style={{position:'absolute',left:'-9999px'}}><label htmlFor="website">Website</label><input id="website" name="website" tabIndex={-1} autoComplete="off"/></div>
 <p className="muted" style={{fontSize:12}}>By submitting, you agree that the business may contact you about this inquiry. Demo data should not include sensitive information.</p>
 <button type="submit" disabled={busy}>{busy?'Sending…':'Submit inquiry'}</button>{result&&<p role="status" className={'alert '+(ok?'':'error')}>{result}</p>}</form>
}
