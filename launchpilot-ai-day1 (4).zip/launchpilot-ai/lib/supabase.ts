import 'server-only';
import { createServerClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';
function config() {
 const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
 const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if (!url || !key) throw new Error('Missing public Supabase environment variables');
 return { url, key };
}
export async function userClient() {
 const store = await cookies(); const {url,key}=config();
 return createServerClient(url,key,{cookies:{
   getAll(){return store.getAll()},
   setAll(values){try{values.forEach(({name,value,options})=>store.set(name,value,options))}catch{/* Server Component: middleware refreshes sessions */}}
 }});
}
export function serviceClient() {
 const {url}=config(); const key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if (!key) throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY');
 return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
}
export async function requireAdmin() {
 const supabase=await userClient();
 const {data:{user},error}=await supabase.auth.getUser();
 if(error||!user) return {supabase,user:null};
 const {data}=await supabase.from('admins').select('user_id').eq('user_id',user.id).maybeSingle();
 return {supabase,user:data?user:null};
}
