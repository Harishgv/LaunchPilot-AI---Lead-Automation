import { z } from 'zod';
export const leadSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254).transform(v => v.toLowerCase()),
  phone: z.string().trim().max(30).optional().default(''),
  message: z.string().trim().min(10).max(2000),
  website: z.string().max(200).optional().default(''), // honeypot
});
export const statusSchema = z.enum(['new','contacted','qualified','won','lost']);
export type LeadStatus = z.infer<typeof statusSchema>;
