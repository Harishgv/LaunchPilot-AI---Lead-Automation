import {describe,it,expect} from 'vitest';
import {leadSchema,statusSchema} from '../lib/validation';
describe('lead validation',()=>{
 it('accepts valid inquiry',()=>expect(leadSchema.safeParse({name:'Asha Rao',email:'ASHA@example.com',message:'Please contact me about the demo.'}).success).toBe(true));
 it('normalizes email',()=>expect(leadSchema.parse({name:'Asha Rao',email:'ASHA@example.com',message:'Please contact me about the demo.'}).email).toBe('asha@example.com'));
 it('rejects invalid email',()=>expect(leadSchema.safeParse({name:'Asha Rao',email:'invalid',message:'Please contact me about the demo.'}).success).toBe(false));
 it('rejects oversized message',()=>expect(leadSchema.safeParse({name:'Asha Rao',email:'asha@example.com',message:'x'.repeat(2001)}).success).toBe(false));
 it('only allows known statuses',()=>expect(statusSchema.safeParse('deleted').success).toBe(false));
});
