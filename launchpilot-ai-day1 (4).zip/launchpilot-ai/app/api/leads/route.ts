import { NextRequest,NextResponse } from 'next/server';
import { createHmac } from 'node:crypto';
import { leadSchema } from '@/lib/validation';
import { serviceClient } from '@/lib/supabase';
export const runtime='nodejs';
export async function POST(request:NextRequest){
 const expected=process.env.NEXT_PUBLIC_SITE_URL;
 // Origin checks limit browser cross-site abuse; they do not authenticate API clients.
 const origin=request.headers.get('origin');
 if(expected && origin && new URL(origin).origin!==new URL(expected).origin)return NextResponse.json({error:'Origin not allowed'},{status:403});
 if(Number(request.headers.get('content-length')||0)>12000)return NextResponse.json({error:'Payload too large'},{status:413});
 let input:unknown;try{input=await request.json()}catch{return NextResponse.json({error:'Invalid JSON'},{status:400})}
 const parsed=leadSchema.safeParse(input);
 if(!parsed.success)return NextResponse.json({error:'Please check your form fields.'},{status:400});
 if(parsed.data.website)return NextResponse.json({ok:true},{status:201});
 const secret=process.env.LEAD_IP_HASH_SECRET;
 if(!secret)return NextResponse.json({error:'Server not configured'},{status:503});
 // Trust forwarding headers only when deployed behind a trusted reverse proxy.
 const ip=request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
 const ipHash=createHmac('sha256',secret).update(ip).digest('hex');
 const {name,email,phone,message}=parsed.data;
 try{
  const db=serviceClient();
  const {data,error}=await db.rpc('submit_public_lead',{p_name:name,p_email:email,p_phone:phone||null,p_message:message,p_ip_hash:ipHash});
  if(error){console.error('Lead RPC error',error.code);return NextResponse.json({error:'Unable to save inquiry'},{status:500})}
  if(data==='rate_limited')return NextResponse.json({error:'Too many submissions. Please try again later.'},{status:429});
  return NextResponse.json({ok:true},{status:201});
 }catch{return NextResponse.json({error:'Service temporarily unavailable'},{status:503})}
}
