 'use server';
import { redirect } from 'next/navigation';
import { userClient } from '@/lib/supabase';
export async function login(formData:FormData){
 const email=String(formData.get('email')||'');const password=String(formData.get('password')||'');
 if(email.length>254||password.length>200||!email||!password)redirect('/login?error=invalid');
 const supabase=await userClient();const {error}=await supabase.auth.signInWithPassword({email,password});
 if(error)redirect('/login?error=invalid');
 redirect('/dashboard');
}
export async function logout(){const supabase=await userClient();await supabase.auth.signOut();redirect('/login')}
