import {redirect} from 'next/navigation';
import {requireAdmin} from '@/lib/supabase';
import {updateStatus} from './actions';
import {logout} from '@/app/login/actions';
import {statusSchema} from '@/lib/validation';
export const dynamic='force-dynamic';
type Lead={id:string;name:string;email:string;phone:string|null;message:string;status:string;created_at:string};
export default async function Dashboard(){
 const {supabase,user}=await requireAdmin();if(!user)redirect('/login');
 const {data,error}=await supabase.from('leads').select('id,name,email,phone,message,status,created_at').order('created_at',{ascending:false}).limit(100);
 if(error)throw new Error('Unable to load leads');
 const leads=(data||[]) as Lead[];
 const count=(s:string)=>leads.filter(x=>x.status===s).length;
 return <main className="wrap"><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:12}}><div><h1>Lead dashboard</h1><p className="muted">Showing the latest 100 leads. Counts reflect this page, not the entire database.</p></div><form action={logout}><button>Sign out</button></form></div>
 <section className="cards">{[['Total',leads.length],['New',count('new')],['Qualified',count('qualified')],['Won',count('won')]].map(([label,value])=><div className="stat" key={label}><span className="muted">{label}</span><strong>{value}</strong></div>)}</section>
 <div className="panel tablewrap"><h2>Recent inquiries</h2><table><thead><tr><th>Received</th><th>Contact</th><th>Message</th><th>Status</th></tr></thead><tbody>{leads.map(lead=><tr key={lead.id}><td>{new Date(lead.created_at).toLocaleDateString('en-GB')}</td><td><strong>{lead.name}</strong><p><a href={'mailto:'+lead.email}>{lead.email}</a></p><small>{lead.phone||'—'}</small></td><td className="message">{lead.message}</td><td><form action={updateStatus}><input type="hidden" name="id" value={lead.id}/><select name="status" defaultValue={lead.status} aria-label={'Status for '+lead.name}>{statusSchema.options.map(s=><option key={s} value={s}>{s}</option>)}</select><button style={{marginTop:8}} type="submit">Save</button></form></td></tr>)}</tbody></table>{!leads.length&&<p className="muted">No leads yet. Submit the public form to create one.</p>}</div></main>
}
