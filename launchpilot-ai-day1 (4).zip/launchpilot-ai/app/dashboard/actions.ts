 'use server';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/supabase';
import { statusSchema } from '@/lib/validation';
export async function updateStatus(formData:FormData){
 const id=String(formData.get('id')||'');const status=statusSchema.safeParse(formData.get('status'));
 if(!/^[0-9a-f-]{36}$/i.test(id)||!status.success)throw new Error('Invalid update');
 const {supabase,user}=await requireAdmin();if(!user)throw new Error('Unauthorized');
 const {error}=await supabase.from('leads').update({status:status.data}).eq('id',id);
 if(error)throw new Error('Unable to update lead');revalidatePath('/dashboard');
}
