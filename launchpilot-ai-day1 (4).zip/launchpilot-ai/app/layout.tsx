import './globals.css';
import Link from 'next/link';
export const metadata={title:'LaunchPilot AI | Lead Automation',description:'Lead capture and CRM demo'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body><header className="nav"><strong>⚡ LaunchPilot AI</strong><nav><Link href="/">Lead form</Link> &nbsp; <Link href="/dashboard">Dashboard</Link></nav></header>{children}</body></html>}
